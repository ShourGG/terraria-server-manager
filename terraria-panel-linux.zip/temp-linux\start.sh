#!/bin/bash
echo "🎮 启动泰拉瑞亚服务器管理面板..."
echo "📁 工作目录: $(pwd)"
echo "🌐 访问地址: http://localhost:8090"
echo ""
./terraria-panel
